package com.example.rgbtohex;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private TextView txtR, txtG, txtB, txtResult;
    private SeekBar seekR, seekG, seekB;

    String red;
    String green;
    String blue;
    String result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtR = findViewById(R.id.txtR);
        txtG = findViewById(R.id.txtG);
        txtB = findViewById(R.id.txtB);
        txtResult = findViewById(R.id.txtResult);


        seekR = findViewById(R.id.seekR);
        seekG = findViewById(R.id.seekG);
        seekB = findViewById(R.id.seekB);


        txtR.setText("R - " + Integer.toString(Map(seekR.getProgress())));
        txtG.setText("G - " + Integer.toString(Map(seekG.getProgress())));
        txtB.setText("B - " + Integer.toString(Map(seekB.getProgress())));

        red = Integer.toHexString(Map(seekR.getProgress()));
        green = Integer.toHexString(Map(seekG.getProgress()));
        blue = Integer.toHexString(Map(seekB.getProgress()));
        result = "#" + red + green + blue;
        txtResult.setText(result);


        seekR.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtR.setText("R - "+Integer.toString(Map(i)));

                red = Integer.toHexString(Map(i));
                green = Integer.toHexString(Map(seekG.getProgress()));
                blue = Integer.toHexString(Map(seekB.getProgress()));
                result = "#" + red + green + blue;
                txtResult.setText(result);




            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        seekG.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtG.setText("G - "+Integer.toString(Map(i)));

                green = Integer.toHexString(Map(i));
                red = Integer.toHexString(Map(seekR.getProgress()));
                blue = Integer.toHexString(Map(seekB.getProgress()));
                result = "#" + red + green + blue;
                txtResult.setText(result);


            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        seekB.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtB.setText("B - "+Integer.toString(Map(i)));

                blue = Integer.toHexString(Map(i));
                red = Integer.toHexString(Map(seekR.getProgress()));
                green = Integer.toHexString(Map(seekG.getProgress()));
                result = "#" + red + green + blue;
                txtResult.setText(result);




            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


    }


    private int Map(int i) {

        float num = (float) i;
        num = (float) (num * 2.55);
        int result = (int) num;
        return result;

    }


}